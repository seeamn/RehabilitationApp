package com.example.rehab_1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import org.w3c.dom.Text;

public class SignUp extends AppCompatActivity {

    EditText emailEdit;
    EditText passwordEdit;
    EditText confirmEdit;
    Button caBtn;
    ProgressBar progressBar;
    TextView signInText;
    TextView guestUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        emailEdit = findViewById(R.id.EmailEdit);
        passwordEdit= findViewById(R.id.PasswordEdit);
        confirmEdit = findViewById(R.id.ConfirmPasswordEdit);
        caBtn = findViewById(R.id.CABtn);
        progressBar = findViewById(R.id.progressBar);
        signInText= findViewById(R.id.signInText);
        guestUser = findViewById(R.id.GuestUser);

        caBtn.setOnClickListener(view -> createAccount());
        signInText.setOnClickListener(view -> finish());

    }
    void createAccount(){
        String email = emailEdit.getText().toString();
        String password = passwordEdit.getText().toString();
        String confirmPassword = confirmEdit.getText().toString();

        boolean isValidated = validation(email,password,confirmPassword);
        if(!isValidated){
            return;
        }
        createAccountInFireBase(email,password);
    }
    void createAccountInFireBase(String email, String password){
        changeInProgress(true);

        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        firebaseAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(SignUp.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(SignUp.this, "Account created, please check email for verification", Toast.LENGTH_SHORT).show();
                    firebaseAuth.getCurrentUser().sendEmailVerification();
                    firebaseAuth.signOut();
                    finish();
                }
                else{
                    Toast.makeText(SignUp.this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
    void changeInProgress(boolean inProgress){
        if(inProgress){
            progressBar.setVisibility(View.VISIBLE);
            caBtn.setVisibility(View.GONE);
        }
        else
        {
            progressBar.setVisibility(View.GONE);
            caBtn.setVisibility(View.GONE);
        }
    }
    boolean validation(String email, String password, String confirmPassword){

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            emailEdit.setError("Email is invalid");
            return false;
        }
        if(password.length()<6){
            passwordEdit.setError("Password is too short");
            return false;
        }
        if(!password.equals(confirmPassword)){
            confirmEdit.setError("Password doesn't match");
            return false;
        }
        return true;
    }
}